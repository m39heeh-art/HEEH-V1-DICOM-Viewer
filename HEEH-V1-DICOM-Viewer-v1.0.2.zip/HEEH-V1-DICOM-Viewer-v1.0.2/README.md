[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.22768910.svg)](https://doi.org/10.5281/zenodo.22768910)
[![ORCID](https://img.shields.io/badge/ORCID-0009--0004--2729--443X-a6ce39?logo=orcid&logoColor=white)](https://orcid.org/0009-0004-2729-443X)
[![CI](https://github.com/m39heeh-art/HEEH-V1-DICOM-Viewer/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/m39heeh-art/HEEH-V1-DICOM-Viewer/actions/workflows/ci.yml)
[![tests](https://img.shields.io/badge/tests-335%20passed-brightgreen)](verification/tests)
[![real-data study](https://img.shields.io/badge/real--data%20study-172%2F172%20exact-blue)](docs/tcia_full_series_study_report.md)
# HEEH-V1(TM) DICOM Viewer

HEEH-V1(TM) DICOM Viewer is a Streamlit web application for **medical-image
research and education**. It supports DICOM and common volumetric-image
workflows, calibrated measurements, image-quality and radiomics-style
calculations, experimental AI integrations, privacy-aware exports, and
provenance reporting.

Open-source research software, version `1.0.2`, released under the MIT
License. **Keywords:** DICOM, medical imaging, research software, radiomics,
medical-image viewer, scientific reproducibility.

**Protected project identity:** the public product name is exactly
**HEEH-V1(TM) DICOM Viewer** (display form: **HEEH-V1™ DICOM Viewer**).
Do not rename or substitute this identity in the application, launchers,
exports, package metadata, documentation, or publication assets.

The official project logo is stored at `assets/heeh-v1-logo.jpg` and is used
as the application page icon and header mark. Keep the logo with the project
identity when publishing or redistributing the application.

> **Research and education disclaimer**
>
> This software is **not a certified medical device** and must not be used for
> diagnosis, prognosis, treatment planning, triage, or any patient-care
> decision. Model labels and overlays describe image or model behavior only;
> they are not medical findings. A qualified clinician must independently
> interpret all images and results.

## Contents

- [Capabilities](#capabilities)
- [Input and navigation](#input-and-navigation)
- [Measurements and calibration](#measurements-and-calibration)
- [Analysis and scientific tools](#analysis-and-scientific-tools)
- [AI, segmentation, and acceleration](#ai-segmentation-and-acceleration)
- [Export and interoperability](#export-and-interoperability)
- [Privacy and security](#privacy-and-security)
- [Standards boundary](#standards-boundary)
- [Installation](#installation)
- [Running the application](#running-the-application)
- [Self-hosted Docker deployment](#self-hosted-docker-deployment)
- [Testing and validation](#testing-and-validation)
- [Project structure](#project-structure)
- [Optional validation data and demonstration samples](#optional-validation-data-and-demonstration-samples)
- [Citation](#citation)
- [Known limitations](#known-limitations)

## Capabilities

### Image ingestion

- DICOM files with `.dcm`, `.dicom`, `.ima`, `.img`, or no extension.
- NIfTI files: `.nii` and `.nii.gz`.
- NRRD files: `.nrrd`.
- MetaImage files: `.mha` and `.mhd`.
- Raster research images: PNG, JPEG, BMP, TIFF, and WebP.
- ZIP archives containing exported or measured images.
- TCIA/NBIA manifest and cached-series workflows.
- Multiple uploaded files and large image sets.
- Physical DICOM ordering using Image Orientation/Position metadata, with
  Instance Number and stable-input fallbacks.
- Detection of DICOM Modality and SOP Class UID before exposing
  modality-specific tools.
- Safe ZIP extraction and archive path checks.

The primary input surface handles both new studies and exported/measured
content. Exported JSON, PNG measurement metadata, de-identified DICOM, and
measurement composites are detected and restored automatically.

#### Support and evidence boundary

“Supported” means a specific ingestion or analysis path exists; it does not
mean every encoding, modality, or vendor variant has been validated. The
current automated evidence includes:

| Data path | Demonstrated behavior | Evidence boundary |
| --- | --- | --- |
| DICOM CT | Pixel loading, rescale to HU, separation of analysis pixels from display windowing, and masking of DICOM Pixel Padding | Synthetic CT fixtures and focused tests; padding is excluded from scalar statistics and shown black; spatial radiomics and CT metrics such as NPS are withheld for masked images until mask-aware implementations are available; not all SOP classes, transfer syntaxes, or vendor implementations |
| DICOM MR | Raw-intensity preservation and MONOCHROME1 display handling | Synthetic MR fixtures; not a validation of quantitative MR biomarkers |
| Compressed DICOM | A TCIA-style compressed image can be decoded in the configured environment | One fixture; decoder availability depends on installed handlers |
| NIfTI | `.nii` volume loading and header scaling | Synthetic test fixtures; broad NIfTI variants and all affine/orientation cases are not established |
| NRRD and MetaImage | `.nrrd` and `.mha` volume loading through SimpleITK | Synthetic fixtures; `.mhd` and the full format/encoding space are not independently established |
| Raster images | Image display paths for common raster formats | Format-specific interoperability and quantitative validity are not established |
| ZIP | Project export/archive validation, including traversal checks | Does not imply support for arbitrary medical-image archive layouts |

Modality detection and modality-specific analysis are separate capabilities.
Availability is feature-specific; a recognized modality does not imply that
every listed metric is validated for it. See `core/modality_registry.py` and
the tests for the implemented feature boundary. This is not a claim to handle
all medical data or all medical-image types.

### Viewer and navigation

- 2D grayscale display with modality-aware presentation.
- CT window center/width and named window presets.
- Native-intensity percentile display for non-CT images.
- MONOCHROME1 inversion handling.
- Color-image display without applying grayscale CT assumptions.
- Slice navigation for volumetric and multi-frame data.
- Image navigation, series browsing, and side-by-side comparison.
- Interactive pixel coordinate and value feedback.
- 1:1 pixel inspection and enlarged display views.
- Accessibility-oriented captions, landmarks, skip links, keyboard hints, and
  contrast helpers.
- Silent background automatic reading for detected exported/measured image
  sets; it is not exposed as a separate visible workflow.

### Volumetric visualization

- Maximum Intensity Projection (MIP).
- Multi-Planar Reconstruction (MPR).
- Interactive Plotly 3D isosurface visualization.
- 2D, 3D, and selected 4D volume normalization.
- Safe handling of empty, non-finite, constant, or out-of-range volume data.
- Full-volume MIP/MPR processing while the normal viewer displays the selected
  middle or navigated slice.

MIP/MPR/3D are research visualizations. They do not replace a validated
diagnostic workstation, calibrated display, or clinical 3D review pipeline.

## Input and navigation

The application keeps physical source data separate from display data:

1. The source array is read and validated.
2. DICOM rescale slope/intercept and modality-specific interpretation are
   applied where appropriate.
3. Measurements and quantitative calculations use the source representation.
4. A separate 8-bit display image is generated for presentation only.

Navigation uses bounded caches for source arrays, rendered display images,
quality results, radiomics, derived CT reports, and pixel-hover payloads.
Cache keys include file identity, input fingerprint, slice, modality,
windowing, inversion, color state, and measurement-composite state. Caches are
bounded to protect memory during large imports.

The application does not impose an arbitrary image-count limit. Large cohorts
are still limited by available memory, upload transport, disk space, decoder
cost, and browser rendering capacity.

## Measurements and calibration

Supported interactive measurements include:

- Point-to-point distance.
- Angle measurement.
- ROI circle and ROI statistics.
- Line-intensity profile.
- Measurement undo and clear operations.
- Per-file and per-slice measurement persistence.
- Reopening of saved measurements from JSON, PNG metadata, composites, and
  export archives.

Measurement rules:

- Coordinates are stored in native source-pixel space.
- DICOM Pixel Spacing is interpreted as row spacing followed by column
  spacing; x uses column spacing and y uses row spacing.
- Distances use physical distance fields in `mm` or `cm`, or `px` when
  physical calibration is unavailable.
- Angles use degrees with the explicit UCUM unit `deg`.
- The first angle point is the vertex.
- Manual calibration is explicitly research-only and must be independently
  validated before use.

Measurement overlays are rendered as presentation products. The original
source pixels remain authoritative for quantitative calculations.

## Analysis and scientific tools

### CT and intensity analysis

- CT Hounsfield Unit conversion using DICOM rescale metadata.
- CT windowing and display presets.
- Tissue classification from documented HU ranges.
- Native-intensity analysis for MR, PET, US, projection radiography, and other
  non-CT modalities where supported.
- Finiteness, physiological-range, and minimum-size validation.
- Whole-image HU statistics.
- Adjacent-difference noise estimates and central-ROI coefficient of variation,
  explicitly labeled as research proxies rather than standardized image-quality
  measurements. The viewer does not report a slice-wide SNR from arbitrary
  anatomical and corner regions.
- Research CNR and other exploratory CT metrics are not clinical acceptance
  criteria; interpret them only with their method, ROI, and limitations.
- Noise Power Spectrum (NPS) summaries where spatial data are sufficient.
- MTF-related research summaries derived from available NPS information.
- Low-contrast detectability proxy.
- Dose metadata display such as CTDIvol when present.
- Exposure-index metadata where available.
- Research tissue-composition summaries.

### Image processing

- Sobel edges.
- Canny edges.
- Gradient magnitude.
- Laplacian processing.
- Windowed overlays and tissue-composition maps.
- ROI crops and line profiles.
- Difference maps and percentage-change helpers.
- Perfusion time-intensity and color-map helpers.
- Vessel-enhancement research processing.

### Metrics

- Dice coefficient.
- Intersection over Union.
- Sensitivity.
- Specificity.
- Precision.
- Hausdorff distance.
- 95th-percentile Hausdorff distance (HD95).
- Average symmetric surface distance (ASSD).
- Explicit defined/undefined/invalid metric result states.
- Mask finiteness, shape, and validity checks.

These are mathematical or research metrics. They do not establish clinical
accuracy, segmentation quality in a patient population, or regulatory
performance.

### Radiomics-style features

- Histogram features including percentiles, skewness, kurtosis, and entropy.
- GLCM-style texture features.
- Shape features.
- Combined radiomics-style reports.
- CSV and XLSX export.

The current implementation is **IBSI-aligned in selected definitions**, not a
claim of full IBSI compliance. Reproducible radiomics requires documented
acquisition, reconstruction, interpolation, discretization, segmentation,
preprocessing, and feature-version choices.

### Longitudinal analysis

- Before/after difference maps.
- Percentage-change summaries.
- Research comparison views.

Longitudinal outputs are not a RECIST implementation or a validated treatment
response assessment.

## AI, segmentation, and acceleration

### PyTorch and Hugging Face models

- Demonstration chest X-ray, brain/MR, and age-classification model paths.
- Modality-gated model availability.
- Cached model loading.
- CPU fallback.
- CUDA device selection when PyTorch reports CUDA availability.
- Frozen evaluation-mode inference for loaded demonstration models.
- Attention overlays for exploratory model-behavior visualization.

ViT preprocessing operates on a rendered display image and may resize it to a
checkpoint input size. It is not super-resolution, reconstruction, or a
replacement for calibrated source data.

### MONAI and SimpleITK

- Lazy MONAI preprocessing to reduce startup cost.
- Volume preprocessing and research segmentation preparation.
- SimpleITK isotropic resampling.
- N4 bias-correction helper.
- Rigid and affine registration helpers.

### Anatomical segmentation

- Optional TotalSegmentator integration when separately installed.
- Optional MONAI Label integration through `MONAI_LABEL_URL`.
- Backend availability reporting.
- Source-volume validation.
- Returned-mask shape validation.
- Empty-mask rejection.

TotalSegmentator and MONAI Label are not bundled by default. The current
application does not claim automatic identification of all organs or bones.

### ONNX Runtime

The ONNX engine prefers `CUDAExecutionProvider` when the installed ONNX Runtime
build exposes it and otherwise falls back to `CPUExecutionProvider`. The
Research compute panel reports:

- PyTorch CUDA availability.
- GPU name and device count.
- Active ONNX provider.
- Providers exposed by ONNX Runtime.

CUDA availability is environment-dependent. The installed package, CUDA
runtime, cuDNN, NVIDIA driver, and model build must be mutually compatible.

## Export and interoperability

The unified Export dialog provides:

- De-identified DICOM PS3.10 file.
- Measurement-data CSV.
- Measurement-data JSON.
- Annotated PNG with measurements and ROI.
- DICOM Structured Report (DICOM SR).
- Radiomics CSV.
- Radiomics XLSX.
- Self-contained HTML research report.
- Cohort metrics CSV.
- All measured images ZIP.
- Machine-readable export provenance manifest.

### Export package contents

Consolidated ZIP exports can contain:

- Pseudonymous filenames such as `heeh_<hash>_image_0001`.
- De-identified DICOM and remapped UIDs.
- DICOM SR using the implemented TID 1500-based measurement structure.
- UCUM units: `mm`, `cm`, `px`, and `deg`.
- RFC 4180-compatible UTF-8 CSV with BOM.
- RFC 8259-compatible JSON.
- Office Open XML XLSX.
- PNG metadata containing normalized measurement JSON.
- Self-contained HTML with HEEH-V1(TM) product identification.
- Per-file cohort status, error code, error message, and source hash fields.
- `export_manifest.json` containing UTC generation time, media types, byte
  counts, SHA-256 hashes, encoding declarations, privacy boundaries, and
  validation requirements.

### Export validation

Run:

```powershell
.\.venv\Scripts\python.exe scripts\validate_export.py path\to\export.zip
```

The validator checks:

- ZIP readability.
- Unsafe absolute and traversal member paths.
- Required export manifest.
- Manifest SHA-256 hashes.
- Unmanifested archive members.
- Common local-path and cache-path leakage.
- Basic DICOM readability.
- Presence of DICOM SR content.
- Measurement angle and distance semantics.
- Cohort status schema.
- Nested export archives.

The validator is a package-integrity tool. It is not a substitute for an
independent DICOM/DICOM SR validator, PACS testing, burned-in annotation
inspection, clinical validation, or regulatory certification.

## Privacy and security

The application provides:

- Curated PHI-field blanking.
- Private-tag removal in de-identified DICOM exports.
- Pseudonymized PatientID.
- UID remapping except required class, transfer, and implementation UIDs.
- PHI-safe audit-context redaction.
- Pseudonymous export stems and source labels.
- SHA-256 integrity hashes.
- Optional Fernet encryption helpers for controlled application integrations.
- Localhost-only launcher defaults.

The application does **not** automatically:

- Remove burned-in identifiers from pixels.
- Apply a validated DICOM date-shift profile.
- Encrypt ZIP archives.
- Provide authentication, authorization, TLS termination, or access control.
- Prove that an export is anonymous.
- Provide HIPAA, GDPR, IHE, DICOM, SNOMED CT, LOINC, or medical-device
  certification.

For identifiable data, deployment must provide authenticated HTTPS, least
privilege, secure transfer, retention and deletion policy, backups, incident
response, audit controls, and a documented privacy risk assessment.

The current stable patient reference is based on a deterministic, unkeyed
hash. It is pseudonymization only: low-entropy identifiers can be guessed and
matched, so it must not be treated as anonymization or as protection against
re-identification.

## Standards boundary

The project is standards-aware and documents relevant boundaries, including:

- DICOM PS3.3, PS3.5, PS3.6, PS3.10, and PS3.16 concepts used by the
  application.
- DICOM Modality, SOP Class, transfer syntax, pixel spacing, windowing, and
  rescale metadata.
- DICOM SR TID 1500/1501/300/320 implementation scope.
- UCUM measurement units.
- DICOM Part 14/GSDF display-calibration boundary.
- RFC 4180-compatible CSV and RFC 8259-compatible JSON.
- Office Open XML XLSX.
- HIPAA/GDPR deployment-control boundaries.
- SNOMED CT and LOINC terminology licensing/version boundaries.
- IHE XDS-I.b, XCA-I, WADO-RS, STOW-RS, QIDO-RS, and ATNA integration
  planning boundaries.
- ACR/AAPM-oriented CT quality references.
- IBSI radiomics reference boundaries.

Relevant reference and boundary documentation is in
[`docs/global_standards_baseline.md`](docs/global_standards_baseline.md) and
[`docs/standards_traceability.md`](docs/standards_traceability.md). Release
measurements and their limitations are documented in
[`docs/VERIFICATION_EVIDENCE.md`](docs/VERIFICATION_EVIDENCE.md). Standards
references describe design intent and implemented conventions; they do not
by themselves establish certification or clinical validation.

## Requirements

- Python 3.11 or 3.12 for the currently tested configuration. The package
  metadata permits Python 3.13 and 3.14, but CI does not yet validate them.
- A working installation of `requirements.lock` or `requirements.txt`.
- Windows, macOS, or Linux.
- Optional NVIDIA GPU with compatible CUDA/PyTorch runtime.
- Optional TotalSegmentator installation.
- Optional MONAI Label server.
- Optional network access for Hugging Face, TCIA/NBIA, or MONAI Label
  integrations.

## Installation

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.lock
pip install -e ".[dev]"
```

### Linux/macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.lock
pip install -e ".[dev]"
```

Optional extras:

```bash
pip install -e ".[finetune]"
pip install -e ".[segmentation]"
```

Use `requirements.txt` rather than the lock file when intentionally updating
the dependency set.

## Running the application

Direct Streamlit launch:

```bash
streamlit run app.py
```

Open `http://localhost:8501`.

Included launchers:

- Windows batch: `app.bat`
- Windows PowerShell: `HEEH-V1 DICOM Viewer.ps1`
- Compatibility PowerShell launcher: `launch.ps1`
- Linux/macOS shell launcher: `HEEH-V1 DICOM Viewer.sh`
- Compatibility shell launcher: `launch.sh`

The launchers bind to `127.0.0.1` by default. Do not expose the application to
a network without an authenticated HTTPS reverse proxy and deployment
security controls.

## Self-hosted Docker deployment

The included Docker Compose profile is a single-instance, CPU-only deployment
baseline for a trusted host. It runs as a non-root user, uses a read-only
application filesystem, limits temporary storage to 4 GB, and binds the web
port to host loopback only. Uploaded files, file-based application logs, and
downloaded model/cache data are temporary. Docker-captured stdout/stderr logs
are retained by the host logging driver, limited to three 10 MB files per
container by default. Do not add persistent mounts for identifiable medical
data without an approved retention, access, backup, and deletion policy.
Decoded image pixels are held in the active session's in-memory cache rather
than Streamlit's process-wide data cache; this does not provide tenant
isolation from host administrators or process-level access.

Requirements: Docker Engine with the Compose plugin and an x86_64 Linux host
with enough RAM and temporary storage for the largest study being processed.
The Compose profile targets `linux/amd64`; other architectures are not
validated. Start and inspect the service with:

```bash
docker compose up --build --detach
docker compose ps
docker compose logs --follow app
```

Open `http://127.0.0.1:8501`; stop it with `docker compose down`. The 512 MB
per-file upload limit and 4 GB temporary-storage limit are deployment defaults,
not capacity guarantees. Adjust both to match the host's tested resource
limits and the reverse proxy's request-body limit.

This service does **not** provide user authentication, authorization, TLS,
tenant isolation, or a secure audit system. Loopback binding is not a
substitute for those controls: host-local users can reach the service. Before
remote or identifiable-data use, put it behind an organization-approved
authenticated HTTPS gateway, restrict host/network access, preserve WebSocket
upgrade headers, set gateway upload/time limits, and complete the applicable
privacy/security review. The default port mapping is intended for a gateway on
the same host. If the gateway runs in a separate container, connect it and this
service through an explicitly managed private Docker network rather than
publishing port 8501 on all host interfaces. Do not expose port 8501 directly
to the internet.
The included image is CPU-only; GPU acceleration needs a separately built and
validated CUDA deployment.

Useful environment variables:

- `HF_TOKEN`: optional Hugging Face access token.
- `MONAI_LABEL_URL`: optional MONAI Label server URL.
- Encryption-key variables documented by `core/security.py`.

## Fine-tuning

The optional fine-tuning path supports:

- Automatic CPU/CUDA device selection.
- Explicit `--device cpu|cuda|auto`.
- FP16 automatic mixed precision on CUDA.
- Gradient accumulation.
- Optional full fine-tuning.
- Layer freezing.
- Accuracy, Macro F1, ROC-AUC, confusion matrix, device, precision, seed, and
  package-version reporting.
- ONNX export and Torch/ONNX parity checks.
- Series-aware validation splitting when series identifiers are available.
- Privacy-preserving `dataset_manifest.json`, `dataset_stats.json`, and
  `run_manifest.json` outputs.
- Training summaries record the split policy, seed, package versions, and model
  revision (`HF_MODEL_REVISION` when supplied; otherwise `not-pinned`).

Example:

```powershell
.\.venv\Scripts\python.exe scripts\finetune.py --help
```

Fine-tuning remains research-only and requires independent dataset governance,
split review, model validation, and reproducibility documentation.

## Real-data benchmark study (v1.0.2)

Beyond synthetic fixtures, the recorded public TCIA CT phantom series
(CT-Phantom4Radiomics, CC BY 4.0, DOI 10.7937/a1v1-rc66) was downloaded
in full and evaluated with the application's own code paths:

- **Exact comparator agreement:** 172/172 slice ROIs match PyRadiomics
  v3.0.1 with 0.0 absolute error (tolerance 1e-6), stable across ROI
  radii of 12-36 mm.
- **CT-number calibration:** air regions within 30 HU of the -1000 HU
  reference on every slice (worst 14.39 HU).
- **Export gate:** all 172 de-identified slices pass; 11/11 corrupted
  manifest probes rejected.
- **IBSI morphology correction:** intensity re-segmentation no longer changes
  the mask used for shape features. The corrected PyRadiomics reference
  extraction passes all 66 comparable IBSI rows; 204 are unsupported because
  no unambiguous PyRadiomics equivalent is available.

Reproduce with `scripts/tcia_real_evaluation.py` and
`scripts/tcia_full_series_study.py` (the series is fetched by NBIA UID
recorded in the scripts; ~44 MB). Reports:
[docs/tcia_real_evaluation_report.md](docs/tcia_real_evaluation_report.md),
[docs/tcia_full_series_study_report.md](docs/tcia_full_series_study_report.md).

## Testing and validation

Run the complete suite:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

Tests requiring optional comparison dependencies, licensed IBSI reference
assets, or recorded benchmark inputs are skipped with an explanatory reason
when those requirements are unavailable. To run the IBSI comparison, install
`pip install -e ".[ibsi]"` and follow `verification/README_DATA.md`.

Run linting:

```powershell
.\.venv\Scripts\python.exe -m ruff check .
```

Check dependencies:

```powershell
.\.venv\Scripts\python.exe -m pip check
```

Run the navigation benchmark:

```powershell
.\.venv\Scripts\python.exe scripts\navigation_benchmark.py
```

The tests cover scientific helpers, metrics, DICOM privacy, export validation,
image preservation, modality detection, DICOM ordering, volume loading,
volumetric visualization, navigation caches, UI helpers, accessibility
contracts, logging, and fine-tuning plumbing. Passing tests demonstrate
software behavior against the test fixtures; they do not prove clinical
accuracy or regulatory compliance.

Evidence labels used in this project:

- **Implemented**: a code path exists; this alone is not validation.
- **Tested**: automated tests exercise the stated behavior on named fixtures.
- **Independently validated**: an external reference or validator was used and
  the exact scope and results are reported.
- **Not established**: no adequate evidence is currently available.

The full suite currently collects 335 tests (335 passed, 0 failed, 0 skipped
locally with the optional IBSI engines and licensed phantom data installed).
The 270/270 IBSI comparison is limited to the specific Configuration D CT
phantom workflow in `verification/tests/test_ibsi_validation.py` and its
recorded verifier output. It uses the Z-Rad reference pipeline; the separate
default viewer radiomics call analyzes a 2D unmasked slice and is reported as
not comparable to Configuration D. The verifier separately reports a
PyRadiomics reference extraction with 66/66 comparable rows passing. An
additional 204 rows were not assessed in that comparison because a defensible
feature mapping was not established; they are not counted as passes or
failures. This is not evidence of full IBSI compliance,
patient-level validity, or generalization across scanners, sites, populations,
modalities, and analysis settings. A separate PyRadiomics 3.0.1 comparison matched four first-order features on one
deterministic synthetic ROI; it does not validate other feature families or
clinical data.

The opt-in IBSI Configuration D result now carries a machine-readable
provenance record: input content fingerprints, application version, dependency
lock hash, runtime/package versions, UTC generation time, and a digest of the
analysis result. The record omits input paths. Input hashes can still enable
linkage and are not anonymization. Other analyses do not yet emit this complete
run record.

### Publication release gate

Before using outputs in a manuscript or sharing data externally, complete the
following independent checks:

- Review every exported image for burned-in identifiers; the application does
  not remove text embedded in pixels automatically.
- Record the exact commit, Python version, dependency lockfile, model revision,
  preprocessing parameters, random seeds, and acquisition/reconstruction
  metadata for each result.
- Validate DICOM and DICOM SR exports with an independent validator and test
  them against the target viewer/PACS.
- Run the official IBSI reference/phantom workflow if radiomics are reported;
  the implementation is research-only and does not claim full IBSI compliance.
- Confirm licenses for any SNOMED CT, LOINC, dataset, model, and third-party
  dependency redistributed with the publication.

These gates are publication controls, not a claim of HIPAA, GDPR, IHE, ISO, or
medical-device certification.

## Project structure

```text
.
|-- app.py                         # Active Streamlit application
|-- Dockerfile                     # CPU-only deployment image
|-- compose.yaml                   # Localhost-bound self-hosted profile
|-- .dockerignore                  # Excludes datasets, uploads, and local artifacts
|-- .streamlit/config.toml         # Production-safe Streamlit defaults
|-- app.bat                        # Windows launcher
|-- HEEH-V1 DICOM Viewer.ps1      # Windows launcher
|-- HEEH-V1 DICOM Viewer.sh       # Linux/macOS launcher
|-- launch.ps1 / launch.sh        # Compatibility launchers
|-- core/                          # Shared domain and safety primitives
|   |-- dicom_ordering.py          # Physical DICOM slice ordering
|   |-- dicom_privacy.py           # De-identification and UID remapping
|   |-- export_validation.py       # Offline ZIP/export validator
|   |-- loaders.py                 # Cached volume/model loaders
|   |-- modality_detector.py       # DICOM modality and SOP detection
|   |-- modality_registry.py       # Capability registry
|   |-- navigation_benchmark.py   # Synthetic navigation benchmark
|   |-- standards.py               # Terminology/privacy boundaries
|   |-- tissue_classifier.py       # Tissue, edge, radiomics, XAI helpers
|   |-- volume_visualizer.py       # MIP/MPR/Plotly 3D
|   `-- security.py                # Optional encryption helpers
|-- engines/                       # Processing and inference engines
|   |-- clinical_metrics.py        # Segmentation and comparison metrics
|   |-- ct_calculator.py           # CT quantitative calculations
|   |-- finetune_trainer.py        # Research fine-tuning
|   |-- monai_preprocessor.py      # MONAI preprocessing
|   |-- onnx_inference.py          # ONNX provider selection
|   |-- sitk_registration.py       # SimpleITK resampling/registration
|   |-- tcia_dataset.py             # TCIA/cache dataset helpers
|   `-- anatomical_segmentation.py # Optional segmentation backends
|-- ui/                            # Compatibility UI exports
|-- utils/                         # Shared utility and AI helpers
|-- scripts/                       # Validation, benchmark, and maintenance CLIs
|-- tests/                         # Automated regression tests
|-- docs/                          # Standards and project documentation
|-- verification/tests/            # Regression and research-validation tests
|-- models/                        # Optional model assets and outputs
|-- requirements.txt               # Range-based dependencies
|-- requirements.lock              # Locked dependencies
|-- pyproject.toml                 # Package, pytest, and Ruff configuration
`-- .gitignore                     # Medical data, secrets, and runtime artifacts
```

`app.py` is the single active Streamlit runtime. `ui/clinical_app.py` is a
compatibility import and does not contain a second UI implementation.

## Optional validation data and demonstration samples

No third-party validation data and no demonstration image archives are
included in this release. The test suite passes without them; the IBSI
phantom tests skip automatically with a clear message when the licensed
data are absent. Some third-party data have license terms that differ from
this project's MIT license (the IBSI CT phantoms are CC BY-NC 3.0), and
medical-image pixel data require an independent privacy review before
redistribution, so this package ships fetch instructions instead of data.
See `verification/README_DATA.md` for the exact fetch commands and the
directory layout the tests expect. For IBSI reference data, consult the
upstream dataset repository at
<https://github.com/theibsi/data_sets> and follow its dataset-specific terms.

`verification/samples/` contains documentation screenshots only. To
generate your own demonstration export, run the application, export, and
validate the archive with `scripts/validate_export.py`.

Do not add patient data, unreviewed image archives, or third-party datasets to
this repository. Before sharing any demonstration export, inspect the image
pixels for burned-in identifiers and confirm all redistribution rights.

## Citation

If you use this software, cite the metadata in
[`CITATION.cff`](CITATION.cff) or the
[Zenodo v1.0.2 record](https://zenodo.org/records/23020151).
Its assigned version DOI is
`10.5281/zenodo.23020151`. Use the
version-family DOI, [10.5281/zenodo.22768910](https://doi.org/10.5281/zenodo.22768910),
when citing the software across all versions. `CITATION.cff` records the
version DOI; `.zenodo.json` identifies the family DOI in its `isVersionOf`
relation. The revised archive retains the requested software version label
`1.0.2` and includes fixes and evidence updates made after the original
`v1.0.2` Git commit; it is not byte-identical to that historical Git snapshot.

## Known limitations

- The application is not a medical device and is not cleared or approved for
  patient care.
- Clinical accuracy is not established by unit tests or standards references.
- DICOM SR and PACS compatibility require independent validation.
- Burned-in pixel annotations require manual review or a validated redaction
  workflow.
- ZIP exports are not encrypted or access-controlled.
- SHA-256 provides integrity, not confidentiality or authenticity.
- Display calibration and DICOM GSDF conformance are deployment concerns.
- Non-DICOM volumes are generic unless modality metadata is supplied.
- Radiomics is not guaranteed to be fully IBSI-compliant.
- Demonstration AI models are not clinically validated.
- MIP/MPR/3D visualizations are research tools, not diagnostic workstation
  replacements.
- Large imports remain bounded by hardware, browser, upload, and storage
  limits.

## License

MIT. See [LICENSE](LICENSE).
